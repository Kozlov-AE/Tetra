﻿namespace MVVM_OpenNewWindowMinimalExample.ViewModels {
    class DialogWindowViewModel {
    }
}