﻿namespace MVVM_OpenNewWindowMinimalExample.ViewModels {
    class OtherWindowViewModel {
    }
}
